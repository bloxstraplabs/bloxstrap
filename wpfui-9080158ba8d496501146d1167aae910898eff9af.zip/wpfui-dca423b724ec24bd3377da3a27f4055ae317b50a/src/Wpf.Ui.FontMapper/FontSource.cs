﻿namespace Wpf.Ui.FontMapper;

struct FontSource
{
    public string Name { get; set; }
    public string Description { get; set; }
    public string SourcePath { get; set; }
    public string DestinationPath { get; set; }
}
