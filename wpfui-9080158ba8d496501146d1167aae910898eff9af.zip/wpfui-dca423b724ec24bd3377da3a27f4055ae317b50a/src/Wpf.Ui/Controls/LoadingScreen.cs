﻿namespace Wpf.Ui.Controls;

/// <summary>
/// Prestyled loading screen with <see cref="ProgressRing"/>.
/// </summary>
public class LoadingScreen : System.Windows.Controls.ContentControl
{
}
