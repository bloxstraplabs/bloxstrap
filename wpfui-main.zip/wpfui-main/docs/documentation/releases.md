# WPF UI Releases

| Version | Is supported |
| ------- | ------------ |
| 3.0.0   | Yes          |
